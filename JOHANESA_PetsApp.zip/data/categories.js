import Category from "../models/category";

export const CATEGORIES=[
    new Category(1,"Animaux de companies"),
    new Category(2,"Betail"),
    new Category(3,"Divers")
]

