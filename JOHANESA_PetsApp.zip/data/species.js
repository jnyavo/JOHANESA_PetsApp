import Species from "../models/specie";
import { CATEGORIES } from "./categories";

export const SPECIES = [
    new Species(1,"Cat",CATEGORIES[0]),
    new Species(2,"Dog",CATEGORIES[0])
]

