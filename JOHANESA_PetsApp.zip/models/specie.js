class Specie
{
    constructor(id,name,category)
    {
        this.id = id;
        this.name = name;
        this.category = category;
    }
}

export default Specie;