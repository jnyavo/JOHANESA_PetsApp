class Breed
{
    constructor(id,name,species)
    {
        this.id = id;
        this.name = name;
        this.species = species;
    }
}

export default Breed;