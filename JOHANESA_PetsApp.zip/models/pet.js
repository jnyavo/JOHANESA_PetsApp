class Pet
{
    constructor(id,name,specie,breed,photo,description)
    {
        this.id = id;
        this.name = name;
        this.specie = specie;
        this.breed = breed;
        this.photo = photo;
        this.description = description;
    }
}
export default Pet;