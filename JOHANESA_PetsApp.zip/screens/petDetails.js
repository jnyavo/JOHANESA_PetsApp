import React,{Component} from 'react';

import {View,Text,Button} from 'react-native';


class petDetailsComponent extends Component
{
    render()
    {
        var Data = this.props.route.params;
        return(
            <View>
                <Text>{Data.pet.description}</Text>
                <Button title="Buy" onPress={()=>{}} />
            </View>
        )
    }
}

export default petDetailsComponent;
